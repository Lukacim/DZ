class GroupOverflowError(Exception):
    """Користувацький виняток для переповнення групи."""
    def __init__(self, message="Група не може містити більше 10 студентів."):
        super().__init__(message)

class Group:
    MAX_STUDENTS = 10

    def __init__(self, name):
        self.name = name
        self.students = set()

    def add_student(self, student):
        if len(self.students) >= self.MAX_STUDENTS:
            raise GroupOverflowError()
        self.students.add(student)

    def delete_student(self, surname):
        self.students = {s for s in self.students if s.surname != surname}

    def find_student(self, surname):
        for student in self.students:
            if student.surname == surname:
                return student
        return None

    def __str__(self):
        return f"Група {self.name}: {', '.join(map(str, self.students))}"
